﻿namespace WindowsMidterm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.txtmiddlename = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtstreet1 = new System.Windows.Forms.TextBox();
            this.txtstreet2 = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtzip = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.lblbye = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Firstname:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Middlename:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lastname:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Street1:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Street2:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 261);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "City:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(70, 306);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "State:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 360);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Zipcode:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(70, 412);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Phone Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(70, 467);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Email:";
            // 
            // txtfirstname
            // 
            this.txtfirstname.BackColor = System.Drawing.SystemColors.Window;
            this.txtfirstname.Location = new System.Drawing.Point(205, 12);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(375, 20);
            this.txtfirstname.TabIndex = 10;
            // 
            // txtmiddlename
            // 
            this.txtmiddlename.BackColor = System.Drawing.SystemColors.Window;
            this.txtmiddlename.Location = new System.Drawing.Point(205, 57);
            this.txtmiddlename.Name = "txtmiddlename";
            this.txtmiddlename.Size = new System.Drawing.Size(375, 20);
            this.txtmiddlename.TabIndex = 11;
            // 
            // txtlastname
            // 
            this.txtlastname.BackColor = System.Drawing.SystemColors.Window;
            this.txtlastname.Location = new System.Drawing.Point(205, 102);
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(375, 20);
            this.txtlastname.TabIndex = 12;
            // 
            // txtstreet1
            // 
            this.txtstreet1.BackColor = System.Drawing.SystemColors.Window;
            this.txtstreet1.Location = new System.Drawing.Point(205, 160);
            this.txtstreet1.Name = "txtstreet1";
            this.txtstreet1.Size = new System.Drawing.Size(375, 20);
            this.txtstreet1.TabIndex = 13;
            // 
            // txtstreet2
            // 
            this.txtstreet2.BackColor = System.Drawing.SystemColors.Window;
            this.txtstreet2.Location = new System.Drawing.Point(205, 207);
            this.txtstreet2.Name = "txtstreet2";
            this.txtstreet2.Size = new System.Drawing.Size(375, 20);
            this.txtstreet2.TabIndex = 14;
            // 
            // txtcity
            // 
            this.txtcity.BackColor = System.Drawing.SystemColors.Window;
            this.txtcity.Location = new System.Drawing.Point(205, 254);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(375, 20);
            this.txtcity.TabIndex = 15;
            // 
            // txtstate
            // 
            this.txtstate.BackColor = System.Drawing.SystemColors.Window;
            this.txtstate.Location = new System.Drawing.Point(205, 303);
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(375, 20);
            this.txtstate.TabIndex = 16;
            // 
            // txtzip
            // 
            this.txtzip.BackColor = System.Drawing.SystemColors.Window;
            this.txtzip.Location = new System.Drawing.Point(205, 360);
            this.txtzip.Name = "txtzip";
            this.txtzip.Size = new System.Drawing.Size(375, 20);
            this.txtzip.TabIndex = 17;
            // 
            // txtphone
            // 
            this.txtphone.BackColor = System.Drawing.SystemColors.Window;
            this.txtphone.Location = new System.Drawing.Point(205, 412);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(375, 20);
            this.txtphone.TabIndex = 18;
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.SystemColors.Window;
            this.txtemail.Location = new System.Drawing.Point(205, 460);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(375, 20);
            this.txtemail.TabIndex = 19;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnsubmit.Location = new System.Drawing.Point(316, 542);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(96, 47);
            this.btnsubmit.TabIndex = 20;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.Location = new System.Drawing.Point(825, 207);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(105, 13);
            this.lblFeedback.TabIndex = 21;
            this.lblFeedback.Text = "Feedback goes here";
            // 
            // lblbye
            // 
            this.lblbye.AutoSize = true;
            this.lblbye.Location = new System.Drawing.Point(825, 499);
            this.lblbye.Name = "lblbye";
            this.lblbye.Size = new System.Drawing.Size(0, 13);
            this.lblbye.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1118, 660);
            this.Controls.Add(this.lblbye);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.txtzip);
            this.Controls.Add(this.txtstate);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtstreet2);
            this.Controls.Add(this.txtstreet1);
            this.Controls.Add(this.txtlastname);
            this.Controls.Add(this.txtmiddlename);
            this.Controls.Add(this.txtfirstname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.TextBox txtmiddlename;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtstreet1;
        private System.Windows.Forms.TextBox txtstreet2;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.TextBox txtzip;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.Label lblbye;
    }
}

